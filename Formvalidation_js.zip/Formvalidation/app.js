let username = document.getElementById('username');
let usermail = document.getElementById('usermail');
let userpass = document.getElementById('userpassword');
var el = document.querySelector('button');

console.log('el el', el);

el.addEventListener("click", (event) => {
    event.preventDefault();
    validateFuncn();
});

function validateFuncn() {
    console.log('in in ');

    if (username.value.trim() === '') {
        onError(username, 'Username cannot be empty');
    } else {
        onSuccess(username);
    }

    if (usermail.value.trim() === '') {
        onError(usermail, 'Usermail cannot be empty');
    } else {
        onSuccess(usermail);
    }
}

function onSuccess(input) {
    let parentel = input.parentElement;
    let parentsmall = parentel.querySelector("small");
    parentel.classList.remove("error");
    parentel.classList.add("success");
    parentsmall.style.visibility = 'none';
    parentsmall.innerHTML = '';
}

function onError(input, message) {
    let parentel = input.parentElement;
    let parentsmall = parentel.querySelector("small");
    parentel.classList.remove("success");
    parentel.classList.add("error");
    parentsmall.style.visibility = 'visible';
    parentsmall.style.color = 'red';
    parentsmall.innerHTML = message;
}